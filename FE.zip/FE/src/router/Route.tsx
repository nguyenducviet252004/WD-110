import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// User Pages
import HomePage from "./pages/HomePage";
import ShopPage from "./Layout/ShopPage";
import BlogPage from "./Layout/BlogPage";
import AboutPage from "./Layout/AboutPage";
import ContactPage from "./Layout/ContactPage";
import CheckoutPage from "./Layout/CheckoutPage";

// Admin Pages & Layout
import AdminLayout from "./layouts/AdminLayout";
import Login from "./pages/admin/Login";
import Dashboard from "./pages/admin/Dashboard";
import Products from "./pages/admin/Products";
import ProductCreate from "./pages/admin/ProductCreate";

function App() {
  return (
    <Router>
      <Routes>
        {/* 👤 USER ROUTES */}
        <Route path="/" element={<HomePage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />

        {/* 🛠️ ADMIN ROUTES */}
        <Route path="/admin/login" element={<Login />} />
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="products" element={<Products />} />
          <Route path="products/create" element={<ProductCreate />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
