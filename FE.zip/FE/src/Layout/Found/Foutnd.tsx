import React from 'react'

const Foutnd = () => {
  return (
    <div>Foutnd</div>
  )
}

export default Foutnd