import { Outlet, Link } from "react-router-dom";

const AdminLayout = () => {
  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-gray-800 text-white p-4 space-y-3">
        <h1 className="text-2xl font-bold">Admin Panel</h1>
        <nav className="space-y-2">
          <Link to="/admin" className="block hover:text-blue-400">Dashboard</Link>
          <Link to="/admin/products" className="block hover:text-blue-400">Products</Link>
          <Link to="/admin/products/create" className="block hover:text-blue-400">Add Product</Link>
        </nav>
      </aside>
      <main className="flex-1 p-6 bg-gray-100">
        <Outlet />
      </main>
    </div>
  );
};

export default AdminLayout;
