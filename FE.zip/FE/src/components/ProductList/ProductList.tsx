import React, { useEffect, useState } from 'react'
import type { IProduct } from '../../types/product'
import { getAllService } from '../../servise/fetch'

const ProductList = () => {
  const [products, setProducts] = useState<IProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
useEffect(() => { 
  const fetchProducts = async () => {
    try {
      const respronse = await getAllService.getAllProducts()
      setProducts(respronse)
      setLoading(false)
    } catch (err) {
      setError('Không thể tải dữ liệu sản phẩm. Vui lòng thử lại sau.')
      setLoading(false)
    } 
  }
  fetchProducts()
}, []);
return (
    <div>
      {error && <div className="error">{error}</div>}
      {loading ? (
        <div className="loading">Đang tải...</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white border rounded-lg p-4 shadow hover:shadow-lg transition-shadow duration-200"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover mb-4 rounded"
              />
              <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-2">{product.description}</p>
              <p className="text-xl font-bold text-blue-600">
                ${product.price.toFixed(2)}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
export default ProductList